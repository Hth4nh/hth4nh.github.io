var fanpage = 'ios.codevn.net', // URL fanpgae
    timeDelay = 5000; // 5 giay sau moi hien

function henrydinhShowFacebookLikebox (fanpage) {
    var facebookOverplay = document.createElement('div');
    facebookOverplay.setAttribute('style', 'position: fixed;left: 0;top: 0;background-color: rgba(0,0,0, 0.8);overflow-x: hidden;height: 100%;width: 100%;z-index: 9999;');
    facebookOverplay.addEventListener('click', () => {
        facebookOverplay.remove();
    });

    var facebookBox = document.createElement('div');
    facebookBox.setAttribute('style', 'position: absolute;left: 50%;top: 35%;margin-left: -170px; margin-top: -108px;');

    var facebookIframe = document.createElement('iframe');
    facebookIframe.setAttribute('src', 'https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2F' +  fanpage + '%2F&amp;tabs&amp;width=340&amp;height=214&amp;small_header=false&amp;adapt_container_width=true&amp;hide_cover=false&amp;show_facepile=true&amp;appId=247582348697830');
    facebookIframe.setAttribute('width', 340);
    facebookIframe.setAttribute('height', 214);
    facebookIframe.setAttribute('style', 'border:none;overflow:hidden');
    facebookIframe.setAttribute('frameborder', 0);
    facebookIframe.setAttribute('allowTransparency', 'true');

    facebookBox.appendChild(facebookIframe);
    facebookOverplay.appendChild(facebookBox);

    document.querySelector('body').appendChild(facebookOverplay);
}

setTimeout(() => {
    if (! localStorage.getItem('showPopupFanpage')) {
        henrydinhShowFacebookLikebox(fanpage);
        localStorage.setItem('showPopupFanpage', true);
    }
}, timeDelay);